#ifndef _MEMORY_USAGE_ENUM_H__
#define _MEMORY_USAGE_ENUM_H__

namespace gf
{

	enum E_MEMORY_USAGE
	{
		EMU_STATIC,
		EMU_DEFAULT,
		EMU_DYNAMIC,
		EMU_STAGING,
		EMU_UNKNOWN
	};


}

#endif
