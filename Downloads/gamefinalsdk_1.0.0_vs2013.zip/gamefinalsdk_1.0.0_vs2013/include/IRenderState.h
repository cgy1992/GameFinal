#ifndef __RENDER_STATE_INTERFACE_H__
#define __RENDER_STATE_INTERFACE_H__

#include "IReferenceCounted.h"

namespace gf
{

	enum E_RENDER_STATE
	{
		ERS_UNKNOWN = 0,
		ERS_FILL_MODE,
		ERS_CULL_MODE,
		ERS_DEPTH_BIAS,
		ERS_DEPTH_BIAS_CLAMP, 
		ERS_SLOPE_SCALED_DEPTH_BIAS, // SlopeScaledDepthBias
		ERS_SCISSOR_ENABLE,
		ERS_MULTISAMPLE_ENABLE,
		ERS_ANTI_LINE_ENABLE,
		ERS_BLEND_ENABLE,
		ERS_SRC_BLEND,
		ERS_DEST_BLEND,
		ERS_BLEND_OP,
		ERS_SRC_BLEND_ALPHA,
		ERS_DEST_BLEND_ALPHA,
		ERS_BLEND_OP_ALPHA,
		ERS_BLEND_WRITE_MASK,
		ERS_ALPHA_COVERAGE_ENABLE,
		ERS_INDEPENDENT_BLEND_ENABLE,
		ERS_DEPTH_ENABLE,
		ERS_DEPTH_WRITE_ENABLE,
		ERS_DEPTH_FUNC,
		ERS_STENCIL_ENABLE,
		ERS_STENCIL_READ_MASK,
		ERS_STENCIL_WRITE_MASK,
		ERS_STENCIL_FAIL_OP,
		ERS_STENCIL_DEPTH_FAIL_OP,
		ERS_STENCIL_PASS_OP,
		ERS_STENCIL_FUNC,
		ERS_BACKFACE_STENCIL_FAIL_OP,
		ERS_BACKFACE_STENCIL_DEPTH_FAIL_OP,
		ERS_BACKFACE_STENCIL_PASS_OP,
		ERS_BACKFACE_STENCIL_FUNC
	};

	enum E_FILL_MODE
	{
		E_FILL_WIREFRAME,
		E_FILL_SOLID
	};

	enum E_CULL_MODE
	{
		E_CULL_NONE,
		E_CULL_CW,
		E_CULL_CCW
	};

	enum E_BLEND_TYPE
	{
		E_BLEND_ZERO = 1,
		E_BLEND_ONE = 2,
		E_BLEND_SRC_COLOR = 3,
		E_BLEND_INV_SRC_COLOR = 4,
		E_BLEND_SRC_ALPHA = 5,
		E_BLEND_INV_SRC_ALPHA = 6,
		E_BLEND_DEST_ALPHA = 7,
		E_BLEND_INV_DEST_ALPHA = 8,
		E_BLEND_DEST_COLOR = 9,
		E_BLEND_INV_DEST_COLOR = 10,
		E_BLEND_SRC_ALPHA_SAT = 11,
		E_BLEND_BLEND_FACTOR = 14,
		E_BLEND_INV_BLEND_FACTOR = 15,
		E_BLEND_SRC1_COLOR = 16,
		E_BLEND_INV_SRC1_COLOR = 17,
		E_BLEND_SRC1_ALPHA = 18,
		E_BLEND_INV_SRC1_ALPHA = 19

	};

	enum E_BLEND_OP
	{
		EBO_ADD = 1,
		EBO_SUBTRACT = 2,
		EBO_REV_SUBTRACT = 3,
		EBO_MIN = 4,
		EBO_MAX = 5
	};


	enum E_STENCIL_OP
	{
		ESO_KEEP,
		ESO_ZERO,
		ESO_REPLACE,
		ESO_INCR_SAT,
		ESO_DECR_SAT,
		ESO_INVERT,
		ESO_INCR,
		ESO_DECR
	};

	class IRenderState : public IReferenceCounted
	{
	public:
		IRenderState(const std::string& name) :mName(name){}

		virtual void set(E_RENDER_STATE state, u32 value) = 0;
		virtual void setFloat(E_RENDER_STATE state, f32 value) = 0;
		virtual void confirm() = 0;
		virtual void cancel() = 0;
		virtual u32 getSortCode() const
		{
			return mSortCode;
		}

		virtual const std::string& getName() const
		{
			return mName;
		}

		

	protected:
		std::string				mName;
		u32						mSortCode;
	};

}


#endif

