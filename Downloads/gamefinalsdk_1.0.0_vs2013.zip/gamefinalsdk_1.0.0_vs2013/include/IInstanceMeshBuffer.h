#ifndef __INSTANCE_MESH_BUFFER_H_INTERFACE__
#define __INSTANCE_MESH_BUFFER_H_INTERFACE__

#include "IRenderableBuffer.h"

namespace gf
{
	class IInstanceMeshBuffer : public IRenderableBuffer
	{
		
	};
}



#endif // !__INSTANCE_MESH_BUFFER_H_INTERFACE__
