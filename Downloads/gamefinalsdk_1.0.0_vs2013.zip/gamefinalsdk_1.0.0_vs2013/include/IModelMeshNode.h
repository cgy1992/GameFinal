#ifndef __MODEL_NODE_INTERFACE_H__
#define __MODEL_NODE_INTERFACE_H__

#include "IMeshNode.h"

/*
class IModelNode : public IMeshNode
{
public:
	IModelNode(ISceneNode* parent,
		ISceneManager* smgr,
		const XMFLOAT3& position = XMFLOAT3(0, 0, 0),
		const XMFLOAT3& rotation = XMFLOAT3(0, 0, 0),
		const XMFLOAT3& scale = XMFLOAT3(1.0f, 1.0f, 1.0f))
		:IMeshNode(parent, smgr, position, rotation, scale)
	{

	}
};

*/

#endif
