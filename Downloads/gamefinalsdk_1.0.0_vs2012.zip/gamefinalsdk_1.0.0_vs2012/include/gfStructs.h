#ifndef __GF_STRUCTS_H__
#define __GF_STRUCTS_H__

namespace gf
{
	template<class T>
	struct SRange
	{
		T MinValue;
		T MaxValue;
	};
}


#endif
